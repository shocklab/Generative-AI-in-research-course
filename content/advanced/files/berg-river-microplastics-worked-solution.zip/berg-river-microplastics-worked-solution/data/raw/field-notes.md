# Berg River microplastics - field notes (season 2026)

Loose notes from the sampling team. Not all of this made it into the
spreadsheets, and some of it contradicts them - read before analysing.

## Equipment

- IMPORTANT: the automated particle counter used at the UPSTREAM site was later
  found to have been DOUBLE-COUNTING all season - it registered each particle
  twice. Every upstream count in the sheet is therefore about twice the true
  figure and must be HALVED to get the real particles/L. The town and downstream
  sites were counted manually and are not affected. (Without this correction the
  upstream counts look almost as high as the town's, which is the whole reason
  the fault was noticed - upstream of a town should not read like the town.)
- The downstream temperature logger failed on 26 March (sample D-07); the
  blank in the sheet is genuine, not a transcription slip.

## Samples to treat with care

- D-03 (downstream, 12 March): the sample bottle cracked in transit and was
  contaminated, which is why its count (118) is far higher than any other
  downstream sample. DISCARD this sample - the value in the sheet should not be
  used.
- D-04 (downstream, 12 March): bottle underfilled, particle count was not
  taken. The blank is intentional.
- D-05 (downstream, 19 March): pH probe error on the day; pH blank is genuine.
- T-07 (town, 26 March): sampled immediately after a storm; counts may be
  unusually high and should be flagged in any interpretation.

## General

- Sites were sampled fortnightly, two grab samples per site per visit.
- "distance_from_town_km" in the metadata is signed: negative is upstream of
  the town, positive is downstream.
