Berg River project - OLD readme (out of date, do not trust)

Files:
  site-A.csv        upstream
  site-B.csv        town
  site-C.csv        downstream
  analysis.xlsx     the analysis spreadsheet

Run analysis.xlsx and update the summary tab.

NOTE: the file names above are stale - the CSVs were renamed and the
old analysis spreadsheet was abandoned. This readme is kept only so you
can see what the project used to look like. Start from the actual files
in data/raw/ instead.
