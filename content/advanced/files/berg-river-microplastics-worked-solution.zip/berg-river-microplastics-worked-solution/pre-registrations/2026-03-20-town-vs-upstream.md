# Pre-registration: do microplastic counts differ across the sites?
# Committed 2026-03-20, before running the analysis.

Question: Is the median microplastic count higher at the town site than at the
  upstream site?

Prediction: Town > upstream, by a margin large enough to matter ecologically
  (we set "matters" at a difference of >= 20 particles/L in advance).

Decision rule:
  - Interesting: town median exceeds upstream by >= 20 particles/L AND the
    difference survives a Mann-Whitney U test at p < 0.05.
  - Boring-but-worth-knowing: a real but smaller difference, or no difference.
    Either way we report it straight.
  - Dead: the data are too sparse or too messy after cleaning to test at all.

Fixed in advance:
  - Outlier rule: exclude only samples the field notes mark unreliable.
  - Missing-value handling: listwise (drop rows with no particle count).
  - Test: Mann-Whitney U (counts are not normally distributed).
  No tuning of these on the results.
