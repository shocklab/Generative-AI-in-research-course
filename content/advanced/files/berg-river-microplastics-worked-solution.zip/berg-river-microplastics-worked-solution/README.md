# Berg River microplastics - worked solution (model answer)

The completed, reproducible version of the Lesson B exercise for the MAM5020F
Advanced Track. It shows what "good" looks like after working through the messy
berg-river-microplastics archive.

## Reproduce it
From this folder:

    python3 scripts/analyse.py

That reads the immutable data in data/raw/, applies the field-note corrections
(logging each to notes/decision-log.md), writes the cleaned data to
data/processed/, runs the pre-registered test, and saves the outputs. The raw
files are never touched - delete data/processed/ and outputs/ and re-run, and
you get them back. (Requires Python with scipy and matplotlib.)

## What's here
  CLAUDE.md                    standing instructions for the agent
  pre-registrations/           the question + decision rule, set before the analysis
  data/raw/                    the original messy files (immutable)
  data/processed/clean.csv     harmonised, corrected data (regenerable)
  scripts/analyse.py           the cleaning + analysis (the method)
  outputs/                     summary table, run log, figure
  notes/decision-log.md        every consequential choice, written by the script
  docs/data-inventory.md       what each raw file is

## The point
The whole result hinges on one logged decision: halving the double-counted
upstream counts (per field-notes.md). Without it, the town and upstream look
identical (no difference). With it, the town is clearly higher. A reader can see
exactly where the result turns - that is what reproducibility buys.

CC BY 4.0.
