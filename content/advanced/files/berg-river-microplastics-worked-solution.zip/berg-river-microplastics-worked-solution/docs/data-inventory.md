# Data inventory

## data/raw/site-upstream.csv
- Upstream site, 12 samples (U-01..U-12), one season.
- Columns: date (ISO), sample_id, particles_per_litre, ph, water_temp_c, notes.
- Rows: 12. Missing: none.
- Known problem: counts sit suspiciously close to the town's, which is odd for a
  site ABOVE the town. field-notes.md explains it - the automated counter
  double-counted all season; halve these counts.

## data/raw/site_town.csv
- Town site, 12 samples (T-01..T-12).
- Columns: Date (DD/MM/YYYY - different format), SampleID, MP_count_per_L, pH,
  temp, comment - different column names from the other files.
- Rows: 12. Missing: none.
- Known problem: T-07 flagged post-storm in field-notes.md (count may be high).

## data/raw/downstream-final-v2.csv
- Downstream site, 12 samples (D-01..D-12).
- Columns: sampling_date, id, particles_L, pH_value, temperature, remarks -
  a third naming convention.
- Rows: 12. Missing: D-04 count, D-05 pH, D-07 temperature.
- Known problem: D-03 count (118) is far above its neighbours; field-notes.md
  says the bottle was contaminated - discard D-03.

## data/raw/sampling-metadata.csv
- Site coordinates, distance from town (signed: negative = upstream), method.

## Notes
- Three files, three column-naming conventions - harmonise before combining.
- field-notes.md is essential: it explains the upstream double-count and the
  D-03 contamination, neither of which is visible from the CSVs alone.
