# CLAUDE.md - Berg River microplastics study

## What this project is
- A field study of microplastic counts at three Berg River sites (upstream of a
  town, in the town, downstream), one sampling season.
- Status: fictional teaching dataset for the MAM5020F Advanced Track.

## Working rules
- Read files before proposing changes.
- Never modify anything in data/raw/. It is the only copy.
- Use plan mode and show me the plan before any consequential change.
- When you summarise or analyse, name which files you used.
- If something is uncertain, say so - never fill a gap with a plausible guess.
- Save reusable code in scripts/; save generated outputs in outputs/.
- Log every consequential decision in notes/decision-log.md, dated, with the reason.
- Run analysis scripts to a committed log; the log, not the figure, is the record.
- Before you tell me a task is done, show me the diff.

## Pre-registration
- The entry in pre-registrations/ is binding. Do not tune on the headline metric;
  do not reframe a result after the fact. If reality contradicts the prediction,
  apply the decision rule and say so.

## Boundaries
- Treat all data as fictional; add no claims about real people or places.
- British spelling.
