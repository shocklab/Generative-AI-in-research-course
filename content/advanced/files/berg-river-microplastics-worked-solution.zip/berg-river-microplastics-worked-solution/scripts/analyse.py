#!/usr/bin/env python3
"""
Berg River microplastics - cleaning and pre-registered analysis (model answer).

Run from the project root:   python3 scripts/analyse.py

Reads the immutable raw data in data/raw/, applies the corrections the field
notes call for (logging each to notes/decision-log.md), writes the cleaned data
to data/processed/, runs the pre-registered test, and saves the outputs. The
raw files are never modified - delete data/processed/ and outputs/ and re-run,
and you get them back.
"""
import csv, statistics
from pathlib import Path
from scipy.stats import mannwhitneyu, kruskal
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent.parent
RAW = ROOT / "data" / "raw"
PROC = ROOT / "data" / "processed"; PROC.mkdir(parents=True, exist_ok=True)
OUT = ROOT / "outputs"; OUT.mkdir(exist_ok=True)
NOTES = ROOT / "notes"; NOTES.mkdir(exist_ok=True)

DATE = "2026-03-20"   # fixed for a reproducible build
decisions = []
def logd(decision, reason, source): decisions.append((decision, reason, source))

def load(fname, colmap):
    with open(RAW / fname) as f:
        return [{k: r[v] for k, v in colmap.items()} for r in csv.DictReader(f)]

up = load("site-upstream.csv", {"id":"sample_id","date":"date","count":"particles_per_litre"})
tn = load("site_town.csv", {"id":"SampleID","date":"Date","count":"MP_count_per_L"})
dn = load("downstream-final-v2.csv", {"id":"id","date":"sampling_date","count":"particles_L"})
for r in up: r["site"] = "upstream"
for r in tn: r["site"] = "town"
for r in dn: r["site"] = "downstream"

# Upstream automated counter double-counted all season -> halve.
for r in up:
    r["count"] = str(int(r["count"]) / 2)
logd("Halved all upstream counts.",
     "The upstream automated counter double-counted all season (recorded ~2x true).",
     "data/raw/field-notes.md, data/raw/site-upstream.csv")

# D-03 contaminated -> exclude.
dn = [r for r in dn if r["id"] != "D-03"]
logd("Excluded downstream sample D-03.",
     "Bottle cracked in transit and was contaminated (count 118, far above neighbours).",
     "data/raw/field-notes.md, data/raw/downstream-final-v2.csv")

# Missing counts -> drop listwise (pre-registered).
rows = up + tn + dn
for r in rows:
    r["count_n"] = float(r["count"]) if r["count"].strip() != "" else None
dropped = [r["id"] for r in rows if r["count_n"] is None]
logd("Dropped " + str(len(dropped)) + " row(s) with no particle count (listwise): " + ", ".join(dropped) + ".",
     "Pre-registered missing-value handling; counts were not taken (e.g. D-04, underfilled bottle).",
     "pre-registrations/2026-03-20-town-vs-upstream.md, data/raw/field-notes.md")
clean = [r for r in rows if r["count_n"] is not None]

with open(PROC / "clean.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["site","sample_id","date","particles_per_litre"])
    for r in clean: w.writerow([r["site"], r["id"], r["date"], r["count_n"]])

def counts(site): return [r["count_n"] for r in clean if r["site"] == site]
up_c, tn_c, dn_c = counts("upstream"), counts("town"), counts("downstream")

lines = []
def out(s): lines.append(s); print(s)
out("PER-SITE PARTICLE COUNTS (particles/L, cleaned)")
for name, c in [("upstream",up_c),("town",tn_c),("downstream",dn_c)]:
    out("  %-11s n=%2d  median=%5.1f  range=%.0f-%.0f" % (name, len(c), statistics.median(c), min(c), max(c)))
out("")
out("PRE-REGISTERED TEST (town vs upstream)")
diff = statistics.median(tn_c) - statistics.median(up_c)
u, p = mannwhitneyu(tn_c, up_c, alternative="greater")
out("  median difference = %.1f  (pre-registered threshold: >= 20)" % diff)
out("  Mann-Whitney U = %.1f, p = %.3g  (pre-registered: p < 0.05)" % (u, p))
out("  DECISION: %s per the pre-registered rule" % ("INTERESTING" if diff >= 20 and p < 0.05 else "no difference"))
out("")
out("EXPLORATORY (all three sites)")
h, pk = kruskal(up_c, tn_c, dn_c)
out("  Kruskal-Wallis H = %.1f, p = %.3g" % (h, pk))

with open(OUT / "summary.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["site","n","median_particles_per_litre"])
    for name, c in [("upstream",up_c),("town",tn_c),("downstream",dn_c)]:
        w.writerow([name, len(c), statistics.median(c)])

fig, ax = plt.subplots(figsize=(6, 4))
data = [up_c, dn_c, tn_c]; labels = ["upstream", "downstream", "town"]
ax.boxplot(data, tick_labels=labels, widths=0.5)
for i, c in enumerate(data, 1):
    ax.scatter([i] * len(c), c, alpha=0.5, color="#003A70", zorder=3)
ax.set_ylabel("microplastics (particles/L)")
ax.set_title("Berg River microplastics by site (cleaned)")
fig.tight_layout(); fig.savefig(OUT / "site_comparison.png", dpi=120)

with open(OUT / "analysis_run.log", "w") as f:
    f.write("\n".join(lines) + "\n")

with open(NOTES / "decision-log.md", "w") as f:
    f.write("# Decision log\n\nEvery consequential cleaning/analysis choice, with its reason and source.\nWritten by scripts/analyse.py.\n\n")
    for d, reason, src in decisions:
        f.write("## " + DATE + " - " + d + "\n- Reason: " + reason + "\n- Source: " + src + "\n\n")

print("")
print("Wrote data/processed/clean.csv, outputs/{summary.csv, analysis_run.log, site_comparison.png}, notes/decision-log.md")
