# Reading notes (rough)

Half-organised notes from the literature - to be turned into a proper
review later. Citations are partial; check before using.

- Microplastics in freshwater rivers: concentrations vary enormously with
  proximity to urban runoff and wastewater outfalls. (review paper - find ref)
- Counting methods are not standardised; particles/L is common but size
  thresholds differ between studies, so cross-study comparison is fraught.
- Several studies report higher counts downstream of urban centres, but
  confounded by flow rate and sampling season.
- TODO: find the standard size-class definitions before claiming our counts
  are comparable to anyone else's.
- TODO: check whether "particles per litre" in our sheets means the same
  thing across all three field teams.
