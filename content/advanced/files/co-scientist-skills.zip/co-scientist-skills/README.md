# Co-scientist research skills

A small bundle of [Claude Code](https://claude.com/claude-code) **Skills** for
reproducible computational research — the research-focused core of the toolkit
that accompanies the guide *Claude Code as a Co-Scientist*.

These are the companion downloads for the **Advanced Track** of the MAM5020F
*Generative AI for Research* course. They are deliberately **human-led**: the
agent removes drudgery and adds rigour, but the ideation, the reading, the
writing, and the judgement — the actual research — stay yours.

## What a Skill is

A Skill is a packaged, reusable workflow: a folder with a `SKILL.md` that tells
the agent *when* to use it and *how*. Claude Code loads it on demand when the
work matches. Skills travel across projects, so a tested research procedure is
written once and reused, rather than re-improvised each session.

## The seven skills

| Skill | What it does |
|---|---|
| `pre-register` | Idea triage **before** you spend time or compute: is this *interesting*, not just publishable? Commit predictions before piloting. |
| `arxiv-fetcher` | Fetch a paper's arXiv source (LaTeX where available) into a workable local form. |
| `academic-pdf-to-mkd` | Convert academic PDFs to clean Markdown, or repair them into searchable, Zotero-ready OCR PDFs. *(Has a one-off local install — see below.)* |
| `paper-review` | A reviewer panel — plus single-reviewer templates: quick-read triage, methods deep-dive, a Gelman-style statistical critique, and a claims-and-press audit. |
| `claim-fact-checker` | Verify every load-bearing claim in a draft or report against the evidence before you commit or publish. |
| `reference-verifier` | Check that citations resolve and actually support what they are cited for (uses Semantic Scholar / Crossref via optional API keys read from the environment). |
| `convergence-check` | An honest read on an iterative loop: are you converging, or spinning? Often the answer is that the data, not the framing, is the bottleneck. |

## Install

```bash
# Copy the skills into Claude Code's skills directory
cp -R skills/* ~/.claude/skills/
```

One skill needs a one-off local setup, because it downloads and runs PDF models
on your machine:

```bash
# Only needed for academic-pdf-to-mkd
brew install uv poppler ocrmypdf ghostscript
uv sync --project ~/.claude/skills/academic-pdf-to-mkd
```

The other six need no setup. `reference-verifier` works without keys, but reads
`SEMANTIC_SCHOLAR_API_KEY` and `REFVERIFY_CONTACT_EMAIL` from the environment if
you have them, for higher rate limits.

## Attribution and licence

`academic-pdf-to-mkd`, `claim-fact-checker`, and `paper-review` are adapted,
with thanks, from **Dominik Lukeš's** openly published agent-skills collection
(MIT licence) — see <https://github.com/techczech/dominiks-agent-skills> and his
workshop <https://techczech.github.io/agents-for-reproducibility/>. The
`CONTEXT.md` / "grill-with-docs" glossary practice is from **Matt Pocock**
(AI Hero). The other four skills are by Jonathan Shock. Full terms are in
[`LICENSE`](LICENSE).
