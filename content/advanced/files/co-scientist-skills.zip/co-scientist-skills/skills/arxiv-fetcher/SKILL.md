---
name: arxiv-fetcher
description: "Fetch LaTeX source and PDF from arXiv papers. Use this skill whenever the user mentions an arXiv paper, arXiv ID, arXiv URL, or asks to download/fetch/pull/get a paper from arXiv. Also triggers when the user wants to read, review, or analyse an arXiv paper and you need to retrieve it first. Handles all arXiv ID formats (2301.12345, 2301.12345v2, hep-th/0601234, arxiv.org URLs). Downloads source .tex files and PDF. Works as a standalone tool or as a prerequisite for the paper-review skill."
---

# arXiv Fetcher

Downloads LaTeX source files and PDFs from arXiv given an arXiv ID or URL.

## When to use

- User provides an arXiv ID or URL and wants to work with the paper
- The paper-review skill needs source files for a cited paper
- User asks to "pull", "fetch", "download", or "get" a paper from arXiv
- Any workflow where you need the .tex source of an arXiv paper

## Quick start

Run the fetch script:

```bash
python /path/to/skill/scripts/fetch_arxiv.py <arxiv_id_or_url> [--output-dir <dir>]
```

The script handles:
- Parsing any arXiv ID format or URL
- Downloading the source tarball from `https://arxiv.org/src/<id>`
- Extracting .tex files (handles tar.gz, gzip-only, and plain tex)
- Downloading the compiled PDF from `https://arxiv.org/pdf/<id>`
- Identifying the main .tex file (the one with `\documentclass`)
- Extracting metadata (title, authors, abstract) from the abstract page

Output is written to `<output-dir>/<arxiv_id>/` with structure:
```
2301.12345/
├── source/          # all extracted source files
│   ├── main.tex     # (or whatever the files are named)
│   ├── appendix.tex
│   ├── figures/
│   └── ...
├── paper.pdf        # compiled PDF from arXiv
├── metadata.json    # title, authors, abstract, categories, dates
└── manifest.json    # lists all files, identifies the main .tex file
```

## Accepted input formats

All of these work:

| Input | Parsed ID |
|-------|-----------|
| `2301.12345` | `2301.12345` |
| `2301.12345v2` | `2301.12345v2` |
| `hep-th/0601234` | `hep-th/0601234` |
| `https://arxiv.org/abs/2301.12345` | `2301.12345` |
| `https://arxiv.org/pdf/2301.12345` | `2301.12345` |
| `https://arxiv.org/src/2301.12345` | `2301.12345` |
| `http://arxiv.org/abs/2301.12345v2` | `2301.12345v2` |
| `arxiv.org/abs/2301.12345` | `2301.12345` |
| `arXiv:2301.12345` | `2301.12345` |

## Fetching multiple papers

To fetch several papers (e.g., all references from a bibliography):

```bash
# From a list of IDs
for id in 2301.12345 2302.67890 hep-th/0601234; do
    python scripts/fetch_arxiv.py "$id" --output-dir ./papers/
done
```

Or call the script's Python API directly:

```python
from scripts.fetch_arxiv import fetch_arxiv_paper
result = fetch_arxiv_paper("2301.12345", output_dir="./papers")
print(result["main_tex"])  # path to main .tex file
print(result["metadata"]["title"])
```

## Extracting arXiv IDs from a .bib or .tex file

A common use case is pulling all cited arXiv papers from a bibliography. To extract IDs:

```python
import re

def extract_arxiv_ids(text):
    """Extract arXiv IDs from bibliography entries, URLs, or citation keys."""
    patterns = [
        r'arxiv[:\s./]*(\d{4}\.\d{4,5}(?:v\d+)?)',           # arXiv:2301.12345
        r'arxiv\.org/(?:abs|pdf|src)/(\d{4}\.\d{4,5}(?:v\d+)?)',  # URL format (new)
        r'arxiv\.org/(?:abs|pdf|src)/([\w-]+/\d{7}(?:v\d+)?)',    # URL format (old)
        r'(\d{4}\.\d{4,5}(?:v\d+)?)',                         # bare new-style ID
        r'([\w-]+/\d{7}(?:v\d+)?)',                            # bare old-style ID
    ]
    ids = set()
    for pattern in patterns:
        ids.update(re.findall(pattern, text, re.IGNORECASE))
    return sorted(ids)
```

Use this to scan a `.bib` file or the bibliography section of a `.tex` file, then fetch each ID.

## Integration with paper-review skill

When the paper-review skill's positioning agent needs to retrieve cited papers:

1. Extract arXiv IDs from the paper's bibliography
2. Fetch each paper using this skill
3. Read the main .tex file (or at minimum the abstract + intro + results from metadata/source)
4. Pass the content to the positioning agent for analysis

The `metadata.json` provides a quick summary without needing to parse the full .tex.

## Error handling

The script handles common failure modes:
- **Source not available**: Some papers don't have source on arXiv (submission-only PDF). The script still downloads the PDF and metadata, and sets `"source_available": false` in manifest.json.
- **Non-tar source**: Some older papers have a single .tex file gzipped (not tarred). The script detects and handles this.
- **Rate limiting**: arXiv rate-limits aggressive scraping. The script includes a configurable delay between requests (default 3 seconds). If fetching many papers, increase this.
- **Network errors**: Retries up to 3 times with exponential backoff.

## Important notes

- **Be respectful of arXiv's servers.** Don't fetch hundreds of papers in rapid succession. The default 3-second delay between requests is the minimum — increase it for bulk fetches.
- **arXiv source is not always LaTeX.** Occasionally papers are submitted as PDF-only, Word documents converted to PDF, or other formats. The script detects this and reports it in manifest.json.
- **Version pinning**: If you need a specific version (e.g., v1 vs v2), include the version suffix in the ID. Without it, arXiv returns the latest version.
