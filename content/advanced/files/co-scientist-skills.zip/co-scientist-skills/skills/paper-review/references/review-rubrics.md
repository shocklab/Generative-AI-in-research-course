# Review Rubrics

Venue-specific scoring rubrics and review criteria. Load the appropriate rubric based on the user's target venue.

If the user specifies a venue not listed here, adapt the closest match and note any venue-specific conventions you know from training data.

---

## NeurIPS (Conference on Neural Information Processing Systems)

**Review dimensions** (each scored 1-10):
- **Soundness**: Are the claims well-supported by theoretical analysis and/or experimental results?
- **Presentation**: Is the paper well-written, well-structured, and clear?
- **Contribution**: Is the contribution significant and novel?
- **Overall**: Aggregated assessment

**Confidence** (1-5):
- 5: Absolutely certain (expert in the exact topic)
- 4: Confident (good knowledge of the area)
- 3: Fairly confident (familiar with the area)
- 2: Willing to defend but not certain
- 1: Educated guess

**Recommendation scale**: Accept (oral) / Accept (poster) / Borderline / Reject

**Venue conventions**:
- 9 pages content + unlimited references + unlimited appendix
- Reproducibility checklist expected
- Ethics statement may be required
- Theory papers expected to have at least proof sketches in main body
- Empirical papers expected to have error bars and multiple runs
- Supplementary material expected for full proofs

**What NeurIPS reviewers prioritise**:
- Novelty and significance of contribution
- Technical correctness
- Clarity and quality of presentation
- Experimental methodology (when applicable)
- Broader impact considerations

---

## ICML (International Conference on Machine Learning)

**Review dimensions** (each scored 1-10):
- **Soundness**: Correctness of claims
- **Significance**: Importance of contribution
- **Novelty**: How new is the approach/result?
- **Clarity**: Quality of writing and presentation
- **Overall**: Aggregated assessment

**Confidence** (1-5): Same scale as NeurIPS

**Recommendation scale**: Strong Accept / Accept / Weak Accept / Borderline / Weak Reject / Reject / Strong Reject

**Venue conventions**:
- 8 pages content + unlimited references + supplementary
- Emphasis on algorithmic/methodological contributions
- Reproducibility checklist
- Position papers and survey papers not typically accepted

**What ICML reviewers prioritise**:
- Methodological novelty
- Strong experimental validation
- Theoretical grounding
- Practical relevance

---

## ICLR (International Conference on Learning Representations)

**Review dimensions** (each scored 1-10):
- **Soundness**: Are claims well-supported?
- **Presentation**: Is the paper clear?
- **Contribution**: Significance and novelty
- **Overall**: Aggregated assessment

**Confidence** (1-5): Same scale as NeurIPS

**Recommendation scale**: 1-10 (where 8+ is accept, 5-7 is borderline, <5 is reject)

**Venue conventions**:
- Open review process (reviews are public)
- Rebuttal period with reviewer-author discussion
- 10 pages content (recently expanded)
- Appendix permitted
- Historically strong on representation learning, deep learning theory, generative models

**What ICLR reviewers prioritise**:
- Understanding and representation of data
- Insights into why methods work (not just that they do)
- Clear experimental protocols
- Theoretical insight (even for empirical papers)

---

## COLT (Conference on Learning Theory)

**Review dimensions** (each scored 1-10):
- **Technical correctness**: Are proofs correct and complete?
- **Significance**: Importance of the result
- **Novelty**: New techniques or just new applications of old techniques?
- **Clarity**: Can an expert follow the proofs?
- **Overall**: Aggregated assessment

**Confidence** (1-5): Same scale

**Recommendation scale**: Accept / Reject

**Venue conventions**:
- Pure theory venue — no experimental results needed
- Full proofs expected (main body or supplementary)
- Emphasis on tight bounds and optimal rates
- Comparisons to known lower bounds expected
- Information-theoretic and computational complexity considerations
- 20-30 pages common for accepted papers (JMLR-published proceedings)

**What COLT reviewers prioritise**:
- Correctness above all else
- Tightness of bounds
- Novel proof techniques
- Connections to other areas of theoretical CS/math
- Clean, elegant results

---

## AAAI (Association for the Advancement of Artificial Intelligence)

**Review dimensions** (each scored 1-10):
- **Significance**: Impact of the contribution
- **Soundness**: Correctness
- **Novelty**: Originality
- **Clarity**: Presentation quality
- **Relevance**: Fit to the conference
- **Overall**: Aggregated assessment

**Confidence** (1-5): Same scale

**Recommendation scale**: Strong Accept / Accept / Weak Accept / Borderline / Weak Reject / Reject / Strong Reject

**Venue conventions**:
- 7 pages content + 1 page references
- Broad AI venue (not just ML)
- Ethics section encouraged
- Appendix limited

**What AAAI reviewers prioritise**:
- Broad relevance to AI
- Clear practical motivation
- Solid experimental evaluation
- Accessibility to a broader AI audience

---

## Nature / Science / PNAS

**Review dimensions** (qualitative, not scored):
- **Significance**: Will this change how people think about the field?
- **Novelty**: Is this fundamentally new?
- **Evidence quality**: Are the conclusions well-supported?
- **Presentation**: Is it accessible to a broad scientific audience?
- **Reproducibility**: Can others replicate this?

**Recommendation scale**: Accept / Minor Revision / Major Revision / Reject

**Venue conventions**:
- Very short main text (Nature: ~3000 words; Science: ~2500 words)
- Extensive supplementary materials
- Must be accessible to scientists outside the subfield
- Emphasis on broad impact and significance
- Lengthy review process with multiple rounds common
- Figures are critically important

**What these reviewers prioritise**:
- "Is this important enough?" is the first question
- Broad impact beyond the immediate subfield
- Rigorous experimental design
- Clarity for non-specialists
- Statistical rigour

---

## JMLR (Journal of Machine Learning Research)

**Review dimensions** (qualitative assessment):
- **Technical quality**: Correctness and depth
- **Novelty**: Originality of contribution
- **Significance**: Impact on the field
- **Clarity**: Quality of exposition
- **Completeness**: Thoroughness of experiments and proofs

**Recommendation scale**: Accept / Minor Revision / Major Revision / Reject

**Venue conventions**:
- No page limit (but reviewers notice bloat)
- Journal quality expected: more thorough than conference papers
- Complete proofs in main body or appendix
- Comprehensive experimental evaluation expected
- Comparison to state-of-the-art required
- Long review cycles (months to years)
- Papers should represent a complete, polished body of work

**What JMLR reviewers prioritise**:
- Completeness and thoroughness
- Technical depth
- Long-term impact over trendy topics
- Clean, readable exposition

---

## Generic / Unspecified Venue

When no venue is specified, use this general rubric:

**Review dimensions** (each scored 1-10):
- **Soundness**: Are claims technically correct and well-supported?
- **Significance**: Does this advance the field in a meaningful way?
- **Novelty**: Is the contribution original?
- **Clarity**: Is the paper well-written and well-structured?
- **Reproducibility**: Could someone replicate the results?
- **Overall**: Aggregated assessment

**Confidence** (1-5)

**Recommendation scale**: Strong Accept / Accept / Weak Accept / Borderline / Weak Reject / Reject

Apply common academic standards: correct claims, fair comparisons, honest limitations, clear writing.
