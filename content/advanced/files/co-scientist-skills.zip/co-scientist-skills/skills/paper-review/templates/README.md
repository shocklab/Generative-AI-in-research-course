# Single-pass review lenses

Optional structured templates for a focused, one-shot review — complementary to
the multi-agent workflow in `../SKILL.md`. Reach for one of these when you want a
single review in a specific register rather than the full specialist panel.

Adapted (MIT) from Dominik Lukeš's `paper-reviewer-skill`
(https://github.com/techczech/dominiks-agent-skills).

| Template | Use for |
|---|---|
| `quick-read.md` | 10–20 min triage: TL;DR, key findings, "should I read deeper?" |
| `methods-deep-dive.md` | Reproducibility + rigour: design, power, data/code availability |
| `gelman-review.md` | Gelman-style stats critique: forking paths, multiple comparisons, "what I'd have done differently" |
| `claims-audit-and-press.md` | Probity audit: every load-bearing claim checked verbatim against the evidence, plus press/news representation |

The **claims-audit** lens pairs naturally with the `claim-fact-checker` skill —
run the audit to identify load-bearing claims, then fan out one verifier per claim.

## Adapting the YAML header

These came from a Zotero + per-paper-folder workflow. For a `.tex`/`.pdf` review,
drop the `paper_key:` (Zotero key) and the `links: [[{folder}/00-source]]` lines,
or replace the link with a wikilink into your own vault. The body structure is the
value; the frontmatter is optional and freely adaptable.

## Deliberately not included

`critical-review.md` from the source skill — its claims/evidence/validity/rating/
verdict structure overlaps the mock-review output the multi-agent synthesis agent
already produces here.
