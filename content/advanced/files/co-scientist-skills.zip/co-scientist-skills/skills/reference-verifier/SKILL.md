---
name: reference-verifier
description: "Verify the references/bibliography of an academic paper. Use this skill whenever the user wants to check, verify, validate, audit, or sanity-check the references, citations, or bibliography of a paper, manuscript, or preprint. Triggers include: 'verify references', 'check the bibliography', 'are these citations real', 'find hallucinated citations', 'check for fake references', 'validate the bib file', 'audit citations', 'check DOIs', 'are the references correct', any mention of LLM-fabricated or AI-hallucinated citations, or requests to confirm that cited works actually exist before submission. Works with .tex/.bib source, .pdf, and .docx inputs. Performs existence checks, metadata cross-validation, DOI resolution, and duplicate/orphan detection — does NOT verify whether the cited paper actually supports the claim."
---

# Reference Verifier

Checks each reference in a paper against authoritative bibliographic databases (Crossref → OpenAlex → Semantic Scholar → arXiv) to catch fabricated references, metadata errors, broken DOIs, and bibliography hygiene issues.

**What this skill does:**
- Existence verification — does the cited work actually exist?
- Metadata cross-validation — do title, authors, year, venue, volume/pages match an authoritative record?
- DOI/arXiv ID resolution
- Duplicate detection (same work cited under two keys)
- Orphan/missing detection (`.tex` only — entries in bibliography but not cited, or vice versa)

**What this skill does NOT do:**
- Semantic claim-support checking (whether the cited paper actually supports the surrounding claim)
- Style/formatting compliance (e.g., enforcing a specific citation style)
- Auto-correction of `.bib` entries (reports only; use `--suggest-fixes` for proposed diffs)

## When to use

- User wants to verify references before submission
- User suspects LLM-assisted writing may have introduced hallucinated citations
- User asks to check a `.bib` file, bibliography section, or reference list for accuracy
- Sanity-checking a manuscript that has gone through multiple revisions

## Quick start

```bash
python /path/to/skill/scripts/verify_references.py <input_file> [options]
```

The script auto-detects input type by extension (`.tex`, `.bib`, `.pdf`, `.docx`). For `.tex` projects with a separate `.bib` file, point to the `.tex` file — the script will locate the `.bib` automatically via the `\bibliography{...}` command, falling back to the `.bbl` if no `.bib` is found.

**Options:**
- `--output <path>` — write Markdown report to this path (default: `<input>_refs_report.md`)
- `--cache-dir <dir>` — override default cache location (`~/.cache/refverify/`)
- `--no-cache` — bypass the cache for this run
- `--concurrency <N>` — parallel API request limit (default: 5; raise carefully)
- `--check-body / --no-check-body` — control orphan/missing detection for `.tex` inputs (default: on if body available)
- `--suggest-fixes` — emit a `<input>_refs_fixes.diff` with proposed bib corrections
- `--strict` — exit non-zero if any reference fails verification (useful in CI)

## Configuration

The script reads the contact email for Crossref's polite pool from the `REFVERIFY_CONTACT_EMAIL` environment variable. Set this once in your shell:

```bash
export REFVERIFY_CONTACT_EMAIL="your.email@institution.edu"
```

If unset, the script falls back to anonymous queries (slower, lower priority) and warns once per run. Without an email, Crossref may rate-limit or deprioritise requests under load.

Optional: set `SEMANTIC_SCHOLAR_API_KEY` if you have one — it raises the rate limit from ~1 req/s to ~100 req/s.

## Input handling

### `.tex` (preferred)

Source input is the most reliable. The script:
1. Reads the `.tex` file and locates `\bibliography{file1,file2}` to find `.bib` files
2. If no `.bib` is referenced or found, falls back to parsing `.bbl` (handles `plain`, `unsrt`, `abbrv`, `apalike`, `natbib`, `acm` styles; warns on others)
3. Parses `.bib` entries with a tolerant BibTeX parser (handles concatenation, string macros, common quirks)
4. If `--check-body` is enabled, scans the `.tex` body for `\cite{...}`, `\citep{...}`, `\citet{...}`, `\citeauthor{...}`, `\autocite{...}`, etc., to detect orphans and missing citations

### `.pdf` (best-effort)

PDF reference extraction is heuristic and lossy. The script:
1. Extracts text via `pdfplumber` (handles two-column layouts reasonably)
2. Locates the references section by header matching (`References`, `Bibliography`, `Literature Cited`, etc.)
3. Segments entries using a multi-strategy parser: numbered (`[1]`, `1.`), author-year (`Smith, J. (2020).`), and indented-block heuristics
4. **Sanity check**: if the in-text citation count (estimated from `[N]` or `(Author, Year)` patterns in the body) differs by >30% from the extracted reference count, the script emits a loud warning recommending the user provide source if available

PDF-extracted entries carry a `source: pdf` flag in the report and are noted as having lower extraction confidence.

### `.docx`

The script walks the document via `python-docx`, locates the references heading (case-insensitive match for `References`, `Bibliography`, etc.), and segments paragraphs. Field codes (Word's native citation manager) are extracted preferentially when present — these are clean structured data, unlike formatted text.

## Verification logic

For each parsed reference, the script attempts identification in this order:

1. **DOI present** → Crossref `works/{doi}` (authoritative, no fuzzy matching needed)
2. **arXiv ID present** → arXiv API direct lookup
3. **Otherwise** → fuzzy bibliographic search:
   - Crossref `works?query.bibliographic=...` with title + first author
   - OpenAlex `works?search=...`
   - Semantic Scholar `graph/v1/paper/search`

Each candidate is scored on:
- Title similarity via `rapidfuzz.fuzz.token_sort_ratio` (0–100)
- Author surname overlap (Jaccard, 0–1)
- Year exact match (+10), ±1 (+5), else 0

A composite score >= **75** is `verified`; **50–74** is `low_confidence`; below 50 is treated as no match found.

## Status taxonomy

Each reference is classified into exactly one of:

| Status | Symbol | Meaning |
|---|---|---|
| `verified` | ✅ | High-confidence match; metadata agrees |
| `metadata_mismatch` | ⚠️ | Match found but ≥1 field disagrees (which fields are listed) |
| `low_confidence` | ⚠️ | Best match below threshold; top candidate shown for human review |
| `not_found` | ❌ | No plausible match across all sources (likely fabricated) |
| `unparseable` | 🔧 | Could not extract structured fields from the entry |
| `duplicate` | 🔁 | Same work cited under two keys (only the later occurrence flagged) |
| `orphan` | 👻 | In bibliography but not cited in body (`.tex` only) |
| `missing` | 🚫 | Cited in body but absent from bibliography (`.tex` only) |

## Output format

The report is a single Markdown file structured as:

```
# Reference verification report
## Summary
| Status | Count |
| --- | --- |
| ✅ Verified | 42 |
| ⚠️ Metadata mismatch | 3 |
| ⚠️ Low confidence | 2 |
| ❌ Not found | 1 |
| 🔧 Unparseable | 0 |
| 🔁 Duplicate | 1 |
| 👻 Orphan | 0 |
| 🚫 Missing | 0 |

**Total references:** 49
**Confidence:** high (parsed from .bib source)

## Issues requiring attention

### ❌ Not found
- **smith2024quantum** — "Quantum entanglement in non-Hermitian systems"
  Authors: J. Smith, A. Doe (2024)
  Searched: Crossref, OpenAlex, Semantic Scholar, arXiv — no match
  *Likely fabricated. Verify with the author or remove.*

### ⚠️ Metadata mismatch
- **jones2021topology** — DOI matches but year disagrees
  Cited: 2021 → Crossref: 2020
  Cited authors: M. Jones → Crossref: M. Jones, R. Patel
  ...

## All verified references
(collapsed by default — full list)
```

## Caching

The cache (default `~/.cache/refverify/cache.json`) is keyed by `(normalised_title, first_author_surname, year)` for fuzzy lookups and by `doi` for direct DOI lookups. Cache entries expire after 30 days. This means re-running the verifier on a revised draft is fast — only new or changed entries hit the network.

To force a fresh run, use `--no-cache`. To clear the cache entirely:
```bash
rm -rf ~/.cache/refverify/
```

## Failure modes and limitations

- **Field coverage is uneven.** Crossref is strongest for journal articles with DOIs. OpenAlex has broader coverage including some non-DOI works. Semantic Scholar is best for CS/ML. arXiv is the only reliable source for un-DOI'd preprints. The cascading fallback handles most cases, but works in books, theses, and grey literature may legitimately not be found in any database — the script flags these as `not_found` even though they're real. Treat `not_found` as "needs human review", not as "definitely fabricated".
- **PDF extraction is fragile.** Two-column layouts, references that span pages, and unusual citation styles can cause silent reference loss. Always provide `.tex` source if you have it. The sanity-check warning helps but is not foolproof.
- **Author name disambiguation is hard.** "J. Smith" is not unique. The scorer uses surname overlap rather than full-name matching, which is more robust to initials/middle-name variations but less precise.
- **Title fuzzy matching has failure modes.** Very short titles ("Attention is all you need") and titles with subtitles can confuse the matcher. The composite score threshold is conservative; expect occasional `low_confidence` flags on legitimate references.
- **Crossref has lag.** Recently published papers (within ~2 weeks) may not be indexed yet. If a recent reference flags as `not_found`, check arXiv or the publisher's site directly.

## Re-running after fixes

Workflow for iterating:
1. Run the verifier; review the report
2. Fix the flagged entries in the source `.bib` / `.docx` / manuscript
3. Re-run — cached entries are skipped, so this is fast
4. Iterate until the summary table shows only `verified` (and optionally accepted `low_confidence` cases)

For CI integration, use `--strict` to fail the build on any non-verified reference.
