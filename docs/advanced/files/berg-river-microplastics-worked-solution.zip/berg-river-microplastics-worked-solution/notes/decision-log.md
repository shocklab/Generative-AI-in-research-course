# Decision log

Every consequential cleaning/analysis choice, with its reason and source.
Written by scripts/analyse.py.

## 2026-03-20 - Halved all upstream counts.
- Reason: The upstream automated counter double-counted all season (recorded ~2x true).
- Source: data/raw/field-notes.md, data/raw/site-upstream.csv

## 2026-03-20 - Excluded downstream sample D-03.
- Reason: Bottle cracked in transit and was contaminated (count 118, far above neighbours).
- Source: data/raw/field-notes.md, data/raw/downstream-final-v2.csv

## 2026-03-20 - Dropped 1 row(s) with no particle count (listwise): D-04.
- Reason: Pre-registered missing-value handling; counts were not taken (e.g. D-04, underfilled bottle).
- Source: pre-registrations/2026-03-20-town-vs-upstream.md, data/raw/field-notes.md

## Assumptions and uncertainty
- Small sample: n = 12 upstream, 12 town, 10 downstream after exclusions, so one or two
  unusual samples (such as T-07, taken after a storm) can move a median noticeably.
- The upstream correction rests on a single field note. Without halving, the upstream
  median would be 68.0 against the town's 70.0, a difference of 2.0, below the
  pre-registered threshold of 20. The result depends on that note being right.
