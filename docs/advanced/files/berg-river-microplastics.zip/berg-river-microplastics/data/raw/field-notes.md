# Berg River microplastics - field notes (season 2026)

Loose notes from the sampling team. Not all of this made it into the
spreadsheets, and some of it contradicts them - read before analysing.

## Equipment

- IMPORTANT: the pH meter used at the TOWN site was faulty all season and
  reported readings ten times too high (it was outputting x10). Every town
  pH value needs dividing by 10 to get the real figure. Upstream and
  downstream used a different, correctly calibrated meter.
- The downstream temperature logger failed on 26 March (sample D-07); the
  blank in the sheet is genuine, not a transcription slip.

## Samples to treat with care

- D-03 (downstream, 12 March): the sample bottle cracked in transit and was
  contaminated. DISCARD this sample - the value in the sheet should not be
  used.
- D-04 (downstream, 12 March): bottle underfilled, particle count was not
  taken. The blank is intentional.
- D-05 (downstream, 19 March): pH probe error on the day; pH blank is genuine.
- T-07 (town, 26 March): sampled immediately after a storm; counts may be
  unusually high and should be flagged in any interpretation.

## General

- Sites were sampled fortnightly, two grab samples per site per visit.
- "distance_from_town_km" in the metadata is signed: negative is upstream of
  the town, positive is downstream.
