# Reproducible project scaffold

An empty version of the structure from the MAM5020F Advanced Track, Lesson B.1.
Copy it, rename it, and adapt. The point of each part:

  CLAUDE.md            standing instructions the agent reads every session
  data/raw/            the original data - never edited
  data/processed/      cleaned data, regenerable from raw + scripts
  scripts/             the code, preserved and re-runnable
  outputs/             figures, tables, reports (derived; never hand-edited)
  notes/decision-log.md   every consequential choice, dated, with reasons
  docs/data-inventory.md  what the data actually is
  pre-registrations/   predictions + decision rules, written before the compute

Apply as much of this as the work deserves - heavy where results must last,
light where they need not. CC BY 4.0.
