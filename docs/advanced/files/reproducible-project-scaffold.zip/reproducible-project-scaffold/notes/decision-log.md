# Decision log

One entry per consequential choice, newest at the top. Each entry: the date,
the decision, the reason, and the source (which file or note it came from).

## YYYY-MM-DD - <short description of the decision>
- Decision:
- Reason:
- Source:
