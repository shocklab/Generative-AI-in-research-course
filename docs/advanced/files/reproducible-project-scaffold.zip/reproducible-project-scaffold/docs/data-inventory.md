# Data inventory

A plain description of each raw data file: what it contains, its columns and
their units, the number of rows, missing values, and any known problems.

## <filename>
- Contents:
- Columns (and units):
- Rows:
- Missing values:
- Known problems / anomalies:
